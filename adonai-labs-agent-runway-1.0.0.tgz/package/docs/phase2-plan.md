# Phase 2: Features Modularization - Implementation Plan

## Current Structure Analysis

### Commands (13 total)
```
src/core/commands/
├── start.md           → CORE (router)
├── validate.md        → FEATURE: tickets
├── lead.md            → FEATURE: implementation
├── fast-lead.md       → FEATURE: implementation
├── express.md         → FEATURE: implementation
├── dry-check.md       → FEATURE: implementation
├── self-review.md     → FEATURE: review
├── review.md          → FEATURE: review
├── security-scan.md   → FEATURE: review
├── architect.md       → FEATURE: architect
├── refactor.md        → FEATURE: refactor
├── iac.md             → FEATURE: iac
└── dotnet.md          → STACK: dotnet
```

### Skills (9 total)
```
src/core/skills/
├── start/             → CORE (router)
├── ticket-creator/    → FEATURE: tickets
├── ticket-eval/     → FEATURE: tickets
├── code-review/       → FEATURE: review
├── architect/         → FEATURE: architect
├── lead/              → FEATURE: implementation
├── express/           → FEATURE: implementation
├── refactor/          → FEATURE: refactor
└── iac/               → FEATURE: iac
```

### Agents (2 total)
```
src/core/agents/
├── architect.md       → FEATURE: architect
└── review.md          → FEATURE: review
```

### Config
```
src/core/config/
├── context-policy.md           → CORE
├── phase-zero-snippet.md       → FEATURE: tickets
├── review-config.md            → FEATURE: review
└── ticket-creator.config.md    → FEATURE: tickets
```

### Memory
```
src/core/memory/
├── common-failures.md      → CORE
├── project-decisions.md    → CORE
├── recurring-patterns.md   → CORE
├── review-findings.md      → FEATURE: review
├── testing-notes.md        → CORE
└── ticket-quality-notes.md → FEATURE: tickets
```

---

## New Structure

```
src/
├── core/                          ← Always installed
│   ├── commands/
│   │   └── start.md               (router only)
│   ├── skills/
│   │   └── start/                 (router only)
│   ├── rules/                     (13 universal rules)
│   ├── config/
│   │   └── context-policy.md
│   └── memory/
│       ├── common-failures.md
│       ├── project-decisions.md
│       ├── recurring-patterns.md
│       └── testing-notes.md
│
├── features/                      ← Modular (user selects)
│   ├── tickets/
│   │   ├── commands/
│   │   │   └── validate.md
│   │   ├── skills/
│   │   │   ├── ticket-creator/
│   │   │   └── ticket-eval/
│   │   ├── config/
│   │   │   ├── phase-zero-snippet.md
│   │   │   └── ticket-creator.config.md
│   │   └── memory/
│   │       └── ticket-quality-notes.md
│   │
│   ├── review/
│   │   ├── commands/
│   │   │   ├── review.md
│   │   │   ├── security-scan.md
│   │   │   └── self-review.md
│   │   ├── skills/
│   │   │   └── code-review/
│   │   ├── agents/
│   │   │   └── review.md
│   │   ├── config/
│   │   │   └── review-config.md
│   │   └── memory/
│   │       └── review-findings.md
│   │
│   ├── architect/
│   │   ├── commands/
│   │   │   └── architect.md
│   │   ├── skills/
│   │   │   └── architect/
│   │   └── agents/
│   │       └── architect.md
│   │
│   ├── implementation/
│   │   ├── commands/
│   │   │   ├── lead.md
│   │   │   ├── fast-lead.md
│   │   │   ├── express.md
│   │   │   └── dry-check.md
│   │   └── skills/
│   │       ├── lead/
│   │       └── express/
│   │
│   ├── refactor/
│   │   ├── commands/
│   │   │   └── refactor.md
│   │   └── skills/
│   │       └── refactor/
│   │
│   └── iac/
│       ├── commands/
│       │   └── iac.md
│       └── skills/
│           └── iac/
│
└── stacks/                        ← Already modular
    ├── dotnet/
    │   ├── commands/
    │   │   └── dotnet.md          (moved from core)
    │   ├── skills/
    │   │   └── dotnet-core/       (already here)
    │   └── ...
    ├── typescript/
    ├── react/
    └── ...
```

---

## Feature Definitions

### 1. tickets (PM/Product Owner)
**Purpose:** Ticket validation and creation
**Users:** PMs, POs, Business Analysts
**Commands:** `/validate`
**Size:** Small (~5% of framework)

### 2. review (Code Reviewer/Tech Lead)
**Purpose:** Code review and security scanning
**Users:** Tech Leads, Senior Devs, Security Engineers
**Commands:** `/review`, `/security-scan`, `/self-review`
**Size:** Medium (~20% of framework)

### 3. architect (Solution Architect)
**Purpose:** Architecture decisions and design
**Users:** Architects, Tech Leads
**Commands:** `/architect`
**Size:** Medium (~15% of framework)

### 4. implementation (Developer)
**Purpose:** Feature implementation workflows
**Users:** Developers
**Commands:** `/lead`, `/fast-lead`, `/express`, `/dry-check`
**Size:** Large (~40% of framework)

### 5. refactor (Developer)
**Purpose:** Safe refactoring
**Users:** Developers
**Commands:** `/refactor`
**Size:** Small (~5% of framework)

### 6. iac (DevOps Engineer)
**Purpose:** Infrastructure as Code
**Users:** DevOps, Platform Engineers
**Commands:** `/iac`
**Size:** Small (~10% of framework)

---

## CLI Updates

### New Feature Presets

```typescript
export const FEATURE_PRESETS: FeaturePreset[] = [
  {
    id: 'tickets',
    name: 'Ticket Management',
    description: 'Validate and create user stories and tickets',
    emoji: '🎫',
  },
  {
    id: 'review',
    name: 'Code Review',
    description: 'Systematic code review and security scanning',
    emoji: '🔍',
  },
  {
    id: 'architect',
    name: 'Architecture',
    description: 'Design decisions and architectural review',
    emoji: '🏗️',
  },
  {
    id: 'implementation',
    name: 'Implementation',
    description: 'Feature development workflows (/lead, /express)',
    emoji: '⚙️',
  },
  {
    id: 'refactor',
    name: 'Refactoring',
    description: 'Safe refactoring patterns',
    emoji: '♻️',
  },
  {
    id: 'iac',
    name: 'Infrastructure as Code',
    description: 'Bicep, Terraform, CloudFormation',
    emoji: '☁️',
  },
  {
    id: 'all',
    name: 'All Features',
    description: 'Complete framework (all commands and skills)',
    emoji: '🎯',
  },
];
```

### Role-Based Presets

```typescript
export const ROLE_PRESETS: RolePreset[] = [
  {
    id: 'pm',
    name: 'Product Manager / PO',
    description: 'Ticket management only',
    emoji: '📋',
    features: ['tickets'],
    stacks: [],
    recommendGlobal: true,
  },
  {
    id: 'reviewer',
    name: 'Code Reviewer / Tech Lead',
    description: 'Review and architecture',
    emoji: '👨‍💼',
    features: ['review', 'architect'],
    stacks: [], // User selects
    recommendGlobal: false,
  },
  {
    id: 'developer',
    name: 'Full-Stack Developer',
    description: 'Implementation, review, refactor',
    emoji: '👨‍💻',
    features: ['implementation', 'review', 'refactor'],
    stacks: [], // User selects
    recommendGlobal: false,
  },
  {
    id: 'devops',
    name: 'DevOps Engineer',
    description: 'Infrastructure and review',
    emoji: '🔧',
    features: ['iac', 'review'],
    stacks: [],
    recommendGlobal: true,
  },
  {
    id: 'architect',
    name: 'Solution Architect',
    description: 'Architecture and review',
    emoji: '🏛️',
    features: ['architect', 'review'],
    stacks: [],
    recommendGlobal: false,
  },
];
```

---

## New CLI Commands

```bash
# By features
npx cursor-runway init --features tickets,review

# By role
npx cursor-runway init --role pm --global
npx cursor-runway init --role developer --stacks typescript,react

# Combined
npx cursor-runway init --features implementation,review --stacks dotnet --global

# Add feature later
npx cursor-runway add-feature architect
npx cursor-runway add-feature review --global
```

---

## Implementation Steps

1. ✅ Create features/ directory structure
2. ✅ Move files from core/ to features/
3. ✅ Update CLI to support --features and --role
4. ✅ Create copyFeatures() utility
5. ✅ Update init command for features
6. ✅ Create add-feature command
7. ✅ Update status command to show features
8. ✅ Update documentation

---

## Migration Strategy

### Backward Compatibility

Old command still works:
```bash
npx cursor-runway init --preset web-fullstack-ts
# → Installs core + all features + typescript + react stacks
```

New granular approach:
```bash
npx cursor-runway init --role developer --stacks typescript,react
# → Installs core + implementation,review,refactor + typescript,react
```

### Config Schema Update

```json
{
  "version": "1.0.0",
  "features": ["implementation", "review"],  // NEW
  "stacks": ["typescript", "react"],
  "installedAt": "2024-01-01T00:00:00.000Z",
  "isGlobal": false
}
```

---

## Testing Checklist

- [ ] Install with --features tickets
- [ ] Install with --role pm --global
- [ ] Add feature to existing installation
- [ ] Status shows features correctly
- [ ] Backward compatibility with old presets
- [ ] Feature dependencies work
- [ ] Global + project features coexist

---

## Estimated Impact

**Files to move:** ~50 files
**New files to create:** ~10 (CLI updates)
**Breaking changes:** None (backward compatible)
**Size reduction for minimal install:** ~80% (core only vs all features)

---

## Benefits

1. **For Users:**
   - Install only what you need
   - Clearer understanding of what's installed
   - Faster setup
   - Less overwhelming for non-devs

2. **For Project:**
   - Better organization
   - Easier to maintain
   - Clearer dependencies
   - Easier to add new features

3. **For Teams:**
   - PMs install tickets globally
   - Devs install implementation per project
   - Clear separation of concerns
