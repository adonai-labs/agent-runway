# Configuration & Memory

---

## Configuration Files (`.cursor/config/`)

### Project configuration (you edit these)

| File | Purpose |
|------|---------|
| `ticket-creator.config.md` | Jira config, personas, doc paths, output settings for ticket generation |
| `review-config.md` | Enable/disable the 21 mandatory review search categories |

### Framework internals (do not edit)

| File | Purpose |
|------|---------|
| `context-policy.md` | How skills select and load context — source priority, load strategy, per-command policy |
| `phase-zero-snippet.md` | Internal config loading logic for the ticket-creator Phase 0 |
| `system-improvements.md` | Auto-generated improvement log from `lead` Phase 10.5 |

---

## Memory Files (`.agent-runway/memory/`)

Curated knowledge that persists across sessions. Skills read these files for pattern recognition and failure avoidance.

| File | Purpose |
|------|---------|
| `project-decisions.md` | Architectural and design decisions made during development |
| `recurring-patterns.md` | Patterns observed across sessions that the agent should recognise and reuse |
| `common-failures.md` | Failure modes the agent should avoid repeating |
| `review-findings.md` | Recurring review findings that should inform future implementation |
| `ticket-quality-notes.md` | Ticket quality patterns to improve implementation readiness |
| `testing-notes.md` | Reusable testing insights, quality gaps, and reliability lessons |
| `errors.md` | Running log of repeated errors, root causes, and prevention |
| `memory.md` | General project memory and notable implementation learnings |
| `repeated-errors.md` | Focused list of recurring failure patterns |

These files ship empty. Populate them as your project evolves — they improve the quality of every skill that reads them.

---

## Project Documentation (`docs/`)

Skills use `docs/` as a primary context source. The load priority is defined in `context-policy.md`.

```
docs/
├── business/
│   ├── entities.md              # Domain entities, relationships, lifecycles
│   └── flows.md                 # User and business process flows
├── Architecture/
│   ├── architecture.md          # System architecture overview
│   ├── decisions.md             # ADRs and architectural decisions
│   └── modules.md               # Module boundaries and responsibilities
├── testing/
│   ├── critical-scenarios.md    # Scenarios that must always be tested
│   └── integration-test-map.md  # Integration points and test coverage
└── examples/
    ├── good-prs.md              # Examples of well-structured PRs
    └── implementation-notes.md  # Lessons learned from past implementations
```

These files ship as placeholders. Even partial content improves context quality significantly.
