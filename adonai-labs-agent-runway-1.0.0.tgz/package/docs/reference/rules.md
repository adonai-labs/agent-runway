# Rules Catalogue

Rules are directives injected automatically into AI context. All rules follow a **directive style** — principles and constraints, not tutorials.

---

## Universal Rules (always active)

| Rule | Purpose |
|------|---------|
| `engineering-principles.mdc` | Clean code, SOLID, naming, error handling, testability, dependency inversion |
| `engineering-security.mdc` | Security fundamentals: input validation, least privilege, secrets management, OWASP |
| `engineering-architecture.mdc` | Architecture principles: layering, boundaries, dependency direction, complexity |
| `owasp-llm-top10.mdc` | LLM security: prompt injection, output handling, tool safety, agency limits |

---

## Scoped Rules (active when matching files are open)

### Language and Framework

| Rule | Glob | Purpose |
|------|------|---------|
| `typescript.mdc` | `**/*.ts`, `**/*.tsx` | Strict config, advanced types, generics, branded types |
| `react.mdc` | `**/*.tsx`, `**/*.jsx` | Components, hooks, state, context, performance, accessibility |
| `dotnet-core.mdc` | `**/*.cs`, `**/*.csproj`, `**/*.sln` | .NET/C# patterns, async, DI, EF Core, validation |
| `rust-development.mdc` | `**/*.rs`, `**/Cargo.toml` | Ownership, borrowing, error handling, concurrency |
| `electron.mdc` | `src/main/**`, `src/renderer/**`, `**/preload.*` | Security, IPC, window management, process separation |
| `advanced-patterns.mdc` | `src/main/**`, `src/renderer/**` | Multi-window, typed IPC, plugins, performance monitoring |

### Architecture and Design

| Rule | Glob | Purpose |
|------|------|---------|
| `api-design.mdc` | `**/controllers/**`, `**/routes/**`, `**/api/**` | REST, versioning, pagination, error handling |
| `database-design.mdc` | `**/migrations/**`, `**/schema/**`, `**/*.sql` | Normalisation, indexing, query optimisation |
| `security.mdc` | `**/*.ts`, `**/*.tsx`, `**/*.cs`, `**/*.rs` | OWASP Top 10, authentication, encryption, input validation |
| `performance.mdc` | `**/*.ts`, `**/*.tsx`, `**/*.cs`, `**/*.rs` | Bundle, memory, rendering, network optimisation |

### Quality and Process

| Rule | Glob | Purpose |
|------|------|---------|
| `testing.mdc` | `**/*.test.*`, `**/*.spec.*`, `**/tests/**` | Testing pyramid, unit/integration/E2E, TDD, quality metrics |
| `code-review.mdc` | `**/*.ts`, `**/*.cs`, `**/*.rs` | Code review scoring, structure, and output format |
| `code-convention.mdc` | `**/*.ts`, `**/*.tsx`, `**/*.js`, `**/*.jsx` | ESLint, naming, type safety, quality scoring |
| `pull-request-templates.mdc` | `.github/**`, `**/*.md` | PR templates, commit conventions, review standards |
| `dependency-check.mdc` | `**/package.json`, `**/*.lock` | Dependency health and security audit (Node.js/npm) |

### AI Security

| Rule | Glob | Purpose |
|------|------|---------|
| `owasp-ai-security-privacy.mdc` | `*.py`, `*.ts`, `*.cs`, `*.js`, `*.go`, `*.java` | AI data governance, privacy, access control, supply chain |

### DevOps

| Rule | Glob | Purpose |
|------|------|---------|
| `devops-practices.mdc` | `.github/**`, `**/*.yml`, `Dockerfile*`, `**/k8s/**` | CI/CD, Docker, Kubernetes, IaC, monitoring |

### Stack-Specific (.NET)

| Rule | Glob | Purpose |
|------|------|---------|
| `dotnet-architecture.mdc` | `**/*.cs`, `**/*.csproj` | Clean Architecture, CQRS, feature-first organisation |
| `dotnet-clean-code.mdc` | `**/*.cs`, `**/*.csproj` | C# naming, async/await, DI, Result pattern, records |
| `dotnet-security.mdc` | `**/*.cs`, `**/*.csproj` | Identity, JWT, Key Vault, EF Core injection prevention |
| `dotnet-testing.mdc` | `**/*.cs`, `**/*.csproj` | xUnit, FluentAssertions, WebApplicationFactory, Testcontainers |
| `dotnet-observability.mdc` | `**/*.cs`, `**/*.csproj` | ILogger, OpenTelemetry, correlation IDs, health checks |

---

## Disabling a Rule

To disable a rule without deleting it, edit its `.mdc` frontmatter:

```yaml
alwaysApply: false
globs: []
```
