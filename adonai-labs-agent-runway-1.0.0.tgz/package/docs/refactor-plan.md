# Refactor Plan: Opción 1 + 3

## Objetivo

1. **Opción 1 - Reglas con Flavors**: Separar reglas universales en `core/` y crear extensiones específicas en `stacks/`
2. **Opción 3 - Presets**: Agregar presets que combinen stacks técnicos + capabilities

---

## Fase 1: Clasificación de Reglas Actuales

### Core Rules (Universales - Mantener/Agregar)

| Regla | Ubicación Actual | Acción | Razón |
|-------|------------------|--------|-------|
| `engineering-principles.mdc` | ✅ core/rules/ | Mantener | Ya universal |
| `engineering-architecture.mdc` | ✅ core/rules/ | Mantener | Ya universal |
| `engineering-security.mdc` | ✅ core/rules/ | Mantener | Ya universal |
| `owasp-llm-top10.mdc` | ✅ core/rules/ | Mantener | Ya universal |
| `owasp-ai-security-privacy.mdc` | ✅ core/rules/ | Mantener | Ya universal |
| `api-design.mdc` | ❌ stacks/dotnet/ | **Mover a core** | REST/HTTP/GraphQL son universales |
| `database-design.mdc` | ❌ stacks/dotnet/ | **Mover a core** | SQL/NoSQL/normalización son universales |
| `performance.mdc` | ❌ stacks/dotnet/ | **Mover a core** | Principios de performance son universales |
| `testing.mdc` | ❌ stacks/dotnet/ | **Mover a core** | Testing pyramid/TDD son universales |
| `devops-practices.mdc` | ❌ stacks/dotnet/ | **Mover a core** | CI/CD/containers son universales |
| `security.mdc` | ❌ stacks/dotnet/ | **Mover a core** | OWASP/auth/encryption son universales |
| `code-review.mdc` | ❌ stacks/typescript/ | **Mover a core** | Criterios de review son universales |
| `pull-request-templates.mdc` | ❌ stacks/typescript/ | **Mover a core** | PRs son universales |

### Stack-Specific Rules (Mantener en stacks/)

#### TypeScript Stack
| Regla | Acción | Razón |
|-------|--------|-------|
| `typescript.mdc` | Mantener | TypeScript específico |
| `advanced-patterns.mdc` | Mantener | Patterns de TS |
| `dependency-check.mdc` | Mantener | npm/node específico |

#### .NET Stack
| Regla | Acción | Razón |
|-------|--------|-------|
| `dotnet-core.mdc` | Mantener | ASP.NET Core específico |
| `dotnet-clean-code.mdc` | Mantener | C# patterns |
| `dotnet-architecture.mdc` | Mantener | CQRS/MediatR/.NET specific |
| `dotnet-security.mdc` | Mantener | IdentityServer/.NET auth |
| `dotnet-testing.mdc` | Mantener | xUnit/NSubstitute |
| `dotnet-observability.mdc` | Mantener | Serilog/App Insights |
| `code-convention.mdc` | Mantener | C# conventions |

#### React Stack
| Regla | Acción | Razón |
|-------|--------|-------|
| `react.mdc` | Mantener | React específico |

---

## Fase 2: Nueva Estructura de Directorios

```
src/
├── core/
│   ├── commands/           (sin cambios)
│   ├── skills/             (sin cambios)
│   ├── agents/             (sin cambios)
│   ├── config/             (sin cambios)
│   ├── memory/             (sin cambios)
│   └── rules/              ⭐ EXPANDIR
│       ├── engineering-principles.mdc
│       ├── engineering-architecture.mdc
│       ├── engineering-security.mdc
│       ├── owasp-llm-top10.mdc
│       ├── owasp-ai-security-privacy.mdc
│       ├── api-design.mdc              ⭐ NUEVO (desde dotnet)
│       ├── database-design.mdc         ⭐ NUEVO (desde dotnet)
│       ├── performance.mdc             ⭐ NUEVO (desde dotnet)
│       ├── testing.mdc                 ⭐ NUEVO (desde dotnet)
│       ├── devops-practices.mdc        ⭐ NUEVO (desde dotnet)
│       ├── security.mdc                ⭐ NUEVO (desde dotnet)
│       ├── code-review.mdc             ⭐ NUEVO (desde typescript)
│       └── pull-request-templates.mdc  ⭐ NUEVO (desde typescript)
│
└── stacks/
    ├── dotnet/
    │   ├── dotnet-core.mdc
    │   ├── dotnet-clean-code.mdc
    │   ├── dotnet-architecture.mdc
    │   ├── dotnet-security.mdc              (específico .NET)
    │   ├── dotnet-testing.mdc               (extensión de testing.mdc)
    │   ├── dotnet-observability.mdc
    │   ├── code-convention.mdc
    │   ├── api-design-dotnet.mdc            ⭐ NUEVO (extensión)
    │   ├── performance-dotnet.mdc           ⭐ NUEVO (extensión)
    │   ├── database-design-dotnet.mdc       ⭐ NUEVO (extensión)
    │   ├── code-review-commands.md
    │   ├── code-review-searches.md
    │   └── skill-dotnet-core/
    │
    ├── typescript/
    │   ├── typescript.mdc
    │   ├── advanced-patterns.mdc
    │   ├── dependency-check.mdc
    │   ├── testing-typescript.mdc           ⭐ NUEVO (extensión)
    │   ├── api-design-typescript.mdc        ⭐ NUEVO (extensión)
    │   ├── code-review-commands.md
    │   └── code-review-searches.md
    │
    ├── react/
    │   ├── react.mdc
    │   ├── testing-react.mdc                ⭐ NUEVO (extensión)
    │   ├── performance-react.mdc            ⭐ NUEVO (extensión)
    │   ├── code-review-commands.md
    │   └── code-review-searches.md
    │
    ├── rust/
    │   └── (similar estructura)
    │
    └── electron/
        └── (similar estructura)
```

---

## Fase 3: Sistema de Presets

### Estructura de Presets

```typescript
// src/cli/presets/index.ts

export interface Stack {
  id: string;
  name: string;
  description: string;
  recommended?: boolean;
}

export interface Capability {
  id: string;
  name: string;
  description: string;
  coreRulesOnly?: boolean;  // Si true, no necesita stacks adicionales
}

export interface Preset {
  id: string;
  name: string;
  description: string;
  emoji: string;
  stacks: string[];
  capabilities?: string[];  // Opcional: capabilities específicas
  recommended?: boolean;
}
```

### Presets Definidos

```typescript
export const PRESETS: Preset[] = [
  // Stack-focused presets
  {
    id: 'web-fullstack-ts',
    name: 'Full-stack Web (TypeScript + React)',
    description: 'SPA moderna con React frontend + API TypeScript/Node backend',
    emoji: '🌐',
    stacks: ['typescript', 'react'],
    recommended: true,
  },
  {
    id: 'dotnet-backend',
    name: '.NET Backend API',
    description: 'REST/gRPC APIs con ASP.NET Core y C#',
    emoji: '⚡',
    stacks: ['dotnet'],
    recommended: true,
  },
  {
    id: 'electron-desktop',
    name: 'Electron Desktop App',
    description: 'Aplicación de escritorio multiplataforma',
    emoji: '🖥️',
    stacks: ['typescript', 'react', 'electron'],
  },
  {
    id: 'rust-systems',
    name: 'Rust Systems Programming',
    description: 'Desarrollo de sistemas de alto rendimiento',
    emoji: '🦀',
    stacks: ['rust'],
  },

  // Capability-focused presets (solo core rules)
  {
    id: 'core-only',
    name: 'Core Only (Sin stacks específicos)',
    description: 'Solo reglas universales - ideal para cualquier lenguaje',
    emoji: '🎯',
    stacks: [],
    coreRulesOnly: true,
  },

  // Mixed presets
  {
    id: 'polyglot-backend',
    name: 'Polyglot Backend',
    description: 'Múltiples lenguajes en el mismo proyecto',
    emoji: '🔀',
    stacks: ['typescript', 'dotnet', 'rust'],
  },

  // Manual selection
  {
    id: 'custom',
    name: 'Selección Manual',
    description: 'Elegir stacks individualmente',
    emoji: '🔧',
    stacks: [], // Se seleccionan después
  },
];
```

---

## Fase 4: Actualización del CLI

### 4.1 Nuevo flujo de `init`

```typescript
// src/cli/commands/init.ts

export async function initCommand(options: InitOptions) {
  console.log(chalk.blue.bold('\n🚀 Cursor Runway Initialization\n'));

  const projectRoot = process.cwd();
  const cursorDir = path.join(projectRoot, '.cursor');
  const configPath = path.join(cursorDir, 'cursor-runway.json');

  // Check if already initialized...

  let selectedStacks: string[];

  if (options.stacks) {
    // CLI: --stacks typescript,react
    selectedStacks = options.stacks.split(',').map((s) => s.trim());
  } else if (options.preset) {
    // CLI: --preset web-fullstack-ts
    const preset = PRESETS.find(p => p.id === options.preset);
    if (!preset) {
      console.log(chalk.red(`Preset "${options.preset}" no encontrado`));
      process.exit(1);
    }
    selectedStacks = preset.stacks;
  } else if (options.yes) {
    // -y flag: usar preset recomendado
    const recommended = PRESETS.find(p => p.recommended);
    selectedStacks = recommended?.stacks || [];
  } else {
    // Interactive: mostrar presets
    selectedStacks = await promptPresetSelection();
  }

  // Instalación...
  const spinner = ora('Instalando Cursor Runway...').start();

  try {
    await fs.ensureDir(cursorDir);

    // Copiar core (siempre)
    spinner.text = 'Copiando reglas universales (core)...';
    await copyCore(projectRoot);

    // Copiar stacks seleccionados
    if (selectedStacks.length > 0) {
      spinner.text = `Instalando stacks: ${selectedStacks.join(', ')}...`;
      await copyStacks(projectRoot, selectedStacks);
    }

    // Crear config
    await createConfig(projectRoot, selectedStacks);

    // Crear docs structure...

    spinner.succeed(chalk.green('✅ Cursor Runway instalado exitosamente!'));

    // Mostrar resumen
    console.log(chalk.blue('\n📋 Instalación:\n'));
    console.log(chalk.green('  ✓ Core rules (universales)'));
    if (selectedStacks.length > 0) {
      console.log(chalk.green(`  ✓ Stacks: ${selectedStacks.join(', ')}`));
    }

    console.log(chalk.blue('\n🎯 Próximos pasos:\n'));
    console.log('1. Popula docs/ con contexto de tu proyecto');
    console.log('2. Abre en Cursor: Ctrl+Shift+P → Developer: Reload Window');
    console.log('3. Ejecuta /start y describe qué quieres hacer\n');
  } catch (error) {
    spinner.fail(chalk.red('Instalación fallida'));
    console.error(error);
    process.exit(1);
  }
}

async function promptPresetSelection(): Promise<string[]> {
  const { preset } = await inquirer.prompt([
    {
      type: 'list',
      name: 'preset',
      message: '¿Qué tipo de proyecto es?',
      choices: PRESETS.map(p => ({
        name: `${p.emoji} ${p.name} - ${chalk.gray(p.description)}`,
        value: p.id,
      })),
    },
  ]);

  const selectedPreset = PRESETS.find(p => p.id === preset);

  if (preset === 'custom') {
    // Mostrar checkbox de stacks
    const { stacks } = await inquirer.prompt([
      {
        type: 'checkbox',
        name: 'stacks',
        message: 'Selecciona stacks:',
        choices: getAvailableStacks().map(s => ({
          name: `${s.name} - ${chalk.gray(s.description)}`,
          value: s.id,
          checked: s.recommended,
        })),
      },
    ]);
    return stacks;
  }

  return selectedPreset?.stacks || [];
}
```

### 4.2 Actualizar `list` command

```typescript
// src/cli/commands/list.ts

export async function listCommand() {
  const projectRoot = process.cwd();
  const configPath = path.join(projectRoot, '.cursor', 'cursor-runway.json');

  if (!(await fs.pathExists(configPath))) {
    // Mostrar presets y stacks disponibles
    console.log(chalk.blue('\n📦 Presets Disponibles:\n'));
    PRESETS.filter(p => p.id !== 'custom').forEach((preset) => {
      console.log(`  ${preset.emoji} ${chalk.green(preset.name)}`);
      console.log(`    ${chalk.gray(preset.description)}`);
      console.log(`    ${chalk.gray(`Stacks: ${preset.stacks.join(', ') || 'solo core'}`)}\n`);
    });

    console.log(chalk.blue('📚 Stacks Disponibles:\n'));
    getAvailableStacks().forEach((stack) => {
      console.log(`  ${chalk.green('○')} ${stack.name} - ${chalk.gray(stack.description)}`);
    });

    console.log(chalk.gray('\nEjecuta `cursor-runway init` para comenzar.\n'));
    return;
  }

  const config = await loadConfig(projectRoot);

  console.log(chalk.blue('\n✅ Instalado:\n'));
  console.log(chalk.green('  ✓ Core rules (universales)'));

  if (config.stacks.length === 0) {
    console.log(chalk.gray('  • Sin stacks adicionales (solo core)\n'));
  } else {
    console.log(chalk.green(`  ✓ Stacks: ${config.stacks.join(', ')}\n`));
  }

  // Mostrar stacks disponibles para agregar
  const availableStacks = getAvailableStacks().filter(
    s => !config.stacks.includes(s.id)
  );

  if (availableStacks.length > 0) {
    console.log(chalk.blue('📦 Stacks Disponibles para Agregar:\n'));
    availableStacks.forEach((stack) => {
      console.log(`  ${chalk.gray('○')} ${stack.name} - ${chalk.gray(stack.description)}`);
    });
    console.log(chalk.gray('\nUsa `cursor-runway add <stack>` para agregar.\n'));
  }
}
```

---

## Fase 5: Estrategia de Migración

### 5.1 Generalizar reglas antes de mover

Cuando movamos reglas a core, debemos generalizarlas:

**Ejemplo: api-design.mdc**

```diff
# Antes (dotnet/api-design.mdc)
- Ejemplos solo en C#/ASP.NET Core
- Menciones de MediatR, FluentValidation

# Después (core/rules/api-design.mdc)
+ Ejemplos multi-lenguaje (pseudocódigo o conceptual)
+ Principios agnósticos (REST, HTTP, etc.)
+ Referencias a extensiones específicas
```

Luego crear extensión:

**dotnet/api-design-dotnet.mdc**
```markdown
---
description: API Design for .NET — ASP.NET Core, MediatR, FluentValidation patterns
globs: "**/*.cs"
alwaysApply: false
---

# API Design for .NET

Extends `core/rules/api-design.mdc` with .NET-specific patterns.

## ASP.NET Core Controllers

... (ejemplos específicos) ...

## MediatR Integration

... (patterns específicos) ...
```

### 5.2 Orden de refactor

1. **Crear extensiones específicas primero** (para no perder contenido)
2. **Generalizar y mover a core**
3. **Actualizar globs** en reglas específicas
4. **Probar instalación**

---

## Fase 6: Testing del Refactor

### 6.1 Test de instalación

```bash
# Test 1: Preset web
npx cursor-runway init --preset web-fullstack-ts

# Verificar:
# - .cursor/rules/ contiene 13 archivos (5 core originales + 8 nuevos)
# - .cursor/rules/ contiene typescript.mdc, react.mdc
# - .cursor/skills/code-review/ tiene searches-typescript.md y searches-react.md

# Test 2: Solo core
npx cursor-runway init --preset core-only

# Verificar:
# - .cursor/rules/ contiene solo 13 archivos universales
# - NO hay stacks específicos

# Test 3: Manual selection
npx cursor-runway init

# Verificar:
# - Muestra presets en el prompt
# - Permite selección custom
```

### 6.2 Test de add/remove

```bash
# Agregar stack después
npx cursor-runway add dotnet

# Verificar:
# - Copia solo archivos de dotnet/
# - Actualiza cursor-runway.json

# Remover stack
npx cursor-runway remove dotnet

# Verificar:
# - Remueve archivos de dotnet/
# - Mantiene core rules
```

---

## Fase 7: Documentación

### 7.1 Actualizar README.md

- Mostrar presets en Quick Start
- Explicar core vs stack rules
- Tabla de presets con sus stacks incluidos

### 7.2 Crear guía de extensiones

- Cómo crear reglas específicas que extienden core
- Convención de nombres: `{topic}-{stack}.mdc`
- Cómo referenciar reglas core

---

## Resumen de Cambios

### Archivos a crear/mover:

**Nuevos archivos:**
- `src/cli/presets/index.ts`
- `src/stacks/dotnet/api-design-dotnet.mdc`
- `src/stacks/dotnet/performance-dotnet.mdc`
- `src/stacks/dotnet/database-design-dotnet.mdc`
- `src/stacks/typescript/api-design-typescript.mdc`
- `src/stacks/typescript/testing-typescript.mdc`
- `src/stacks/react/testing-react.mdc`
- `src/stacks/react/performance-react.mdc`

**Mover a core/rules/:**
- `dotnet/api-design.mdc` → `core/rules/api-design.mdc`
- `dotnet/database-design.mdc` → `core/rules/database-design.mdc`
- `dotnet/performance.mdc` → `core/rules/performance.mdc`
- `dotnet/testing.mdc` → `core/rules/testing.mdc`
- `dotnet/devops-practices.mdc` → `core/rules/devops-practices.mdc`
- `dotnet/security.mdc` → `core/rules/security.mdc`
- `typescript/code-review.mdc` → `core/rules/code-review.mdc`
- `typescript/pull-request-templates.mdc` → `core/rules/pull-request-templates.mdc`

**Actualizar:**
- `src/cli/commands/init.ts` - agregar soporte de presets
- `src/cli/commands/list.ts` - mostrar presets
- `src/cli/index.ts` - agregar flag `--preset`
- `README.md` - documentar presets
- `EXTENDING.md` - explicar extensiones

**Total:**
- ~8 archivos nuevos (extensiones)
- ~8 archivos a mover
- ~5 archivos a actualizar
- ~2 archivos de documentación

---

## Timeline Estimado

- **Fase 1**: Clasificación - ✅ Completado
- **Fase 2**: Estructura - 30min
- **Fase 3**: Sistema de presets - 1h
- **Fase 4**: CLI updates - 1.5h
- **Fase 5**: Migración de reglas - 2h
- **Fase 6**: Testing - 1h
- **Fase 7**: Documentación - 1h

**Total: ~7 horas de trabajo**

---

## Próximos Pasos

1. ✅ Revisar y aprobar este plan
2. ⏳ Crear estructura de presets
3. ⏳ Actualizar CLI
4. ⏳ Mover reglas a core (generalizando)
5. ⏳ Crear extensiones específicas
6. ⏳ Testing completo
7. ⏳ Actualizar documentación
