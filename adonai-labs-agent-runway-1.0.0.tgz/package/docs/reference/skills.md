# Skills & Workflows

Skills are the workflows behind each command. They define phases, quality gates, reference loading, and output format.

---

## Delivery Lifecycle

```
ticket-creator ──→ lead ──→ code-review ──→ refactor
  (create)        (build)   (validate)     (improve)
```

---

## Core Skills

| Skill | Phases | Purpose |
|-------|--------|---------|
| `ticket-creator` | 8 phases | Creates development-ready tickets from a brief description, Jira key, or markdown file. Combines PO and BA perspectives. |
| `lead` | 10 phases + gates | Implements features end-to-end: exploration, requirements, planning, DRY analysis, implementation, testing, self-review, verification, code review delegation, commit. |
| `code-review` | 6 phases | Runs 21 mandatory search patterns before manual analysis. Produces a structured report with severity-classified findings and a verdict. |
| `refactor` | 5 steps | Guided refactoring with characterisation tests, systematic smell detection, incremental changes, and safety verification. |

---

## Supporting Skills

| Skill | Purpose |
|-------|---------|
| `start` | Intent classification and skill routing — the entry point when you don't know which command to use. |
| `architect` | Evaluates design proposals, trade-offs, and boundaries. Stack-agnostic. Invoked by `lead` for Complex tasks or directly for standalone analysis. |
| `ticket-eval` | Classifies ticket type and checks completeness against 7 criteria. Produces a READY TO DEV verdict. |
| `po-eval` | Evaluates spec/ticket quality from a Product Owner lens and returns a PRODUCT READY verdict with business gaps and actions. |
| `express` | Five phases, no approval gates. For well-scoped tasks where the developer has full context. |

---

## Agents

Agents run in an **isolated context window** — they do not see the parent conversation. This avoids context contamination and produces focused, independent analysis.

| Agent | Invoked by | Direct use | Purpose |
|-------|------------|------------|---------|
| `architect` | `lead` Phase 0 (Complex tasks) | `/architect` | Trade-off analysis, approach recommendation, ADRs |
| `review` | `lead` Phase 9 | `/review` | Evidence-based review with APPROVE / REQUEST CHANGES / NEEDS DISCUSSION verdict |

Both agents are **read-only** — they analyse and report but do not modify files.

---

## Stack Modules

Stack-specific references loaded by `lead` and `code-review` during implementation and review.

| Module | Reference files | Contents |
|--------|-----------------|---------|
| `dotnet-core` | 8 files | Architecture, CQRS/MediatR, EF Core, messaging, caching, API design, xUnit, Testcontainers, OpenTelemetry |
| `express` | 1 file | Node.js / Express patterns for minimal-friction implementation |
| `iac` | 2 files | Bicep and Terraform standards for .NET applications on Azure |

To add a new stack module, see [EXTENDING.md](../../EXTENDING.md).
